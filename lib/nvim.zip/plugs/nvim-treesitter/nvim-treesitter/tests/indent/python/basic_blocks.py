from os import (
    path,
    name as OsName
)

def foo(x):
    pass

class Foo:
    def __init__(self):
        pass

    def foo(self):
        pass
