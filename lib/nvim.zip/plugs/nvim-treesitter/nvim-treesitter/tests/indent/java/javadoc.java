public class Foo {
  /**
   */
  void foo() {}
}
