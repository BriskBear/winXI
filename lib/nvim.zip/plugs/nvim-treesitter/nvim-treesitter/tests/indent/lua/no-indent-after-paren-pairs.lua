-- Issue #2476
require("treesitter").setup(
)

local table = {
}
