require('cmp').register_source('cmdline', require('cmp_cmdline').new())
